package com.factory.appraisal.vehiclesearchapp.services;
import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.ConfigCodesMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.repository.EConfigurationCodesRepo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
@Author("Yogesh Kumar V")
@Service
public class EConfigurationCodesServiceImpl implements EConfigurationCodesService{
    @Autowired
    private EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    private ConfigCodesMapper configCodesMapper;

    @Override
    public ConfigurationCodes addConfigCode(ConfigurationCodes configurationCodes) {
        EConfigurationCodes eConfigurationCodes=configCodesMapper.dtoToModel(configurationCodes);
        return configCodesMapper.modelToDto(eConfigurationCodesRepo.save(eConfigurationCodes));
    }

    @Override
    public List<ConfigurationCodes> GetConfigCodes(Integer pageNo, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by("createdOn").descending());
        Page<EConfigurationCodes>pageResult=eConfigurationCodesRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);
        List<EConfigurationCodes>eConfigurationCodes = pageResult.toList();
        List<ConfigurationCodes>configurationCodes=configCodesMapper.modelsToDtos(eConfigurationCodes);
        return configurationCodes;
    }

    @Override
    public ConfigurationCodes updateConfigCodes(long codeId, ConfigurationCodes configurationCodes) {
        EConfigurationCodes eConfigurationCodes=eConfigurationCodesRepo.findById(codeId).get();
        if (eConfigurationCodes!=null){
            if (configurationCodes.getValid()!=false){
                if (configurationCodes.getCodeType()!=null){
                    eConfigurationCodes.setCodeType(configurationCodes.getCodeType());
                }
                if (configurationCodes.getLongCode()!=null){
                    eConfigurationCodes.setLongCode(configurationCodes.getLongCode());
                }
                if (configurationCodes.getShortCode()!=null){
                    eConfigurationCodes.setShortCode(configurationCodes.getShortCode());
                }
                if (configurationCodes.getShortDescription()!=null) {
                    eConfigurationCodes.setShortDescription(configurationCodes.getShortDescription());
                }
                eConfigurationCodes.setCreatedBy(configurationCodes.getCreatedBy());
                eConfigurationCodes.setCreatedOn(configurationCodes.getCreatedOn());
                eConfigurationCodes.setModifiedBy(configurationCodes.getModifiedBy());
                eConfigurationCodes.setModifiedOn(configurationCodes.getModifiedOn());
            }
            return configCodesMapper.modelToDto(eConfigurationCodes);
        }
        else throw new RuntimeException("Did not find ConfigCodes of "+codeId);
    }

    @Override
    public String deleteConfigCodes(long codeId) {
        EConfigurationCodes eConfigurationCodes = eConfigurationCodesRepo.findById(codeId).get();
        if(eConfigurationCodes!=null){
            eConfigurationCodes.setValid(false);
            eConfigurationCodesRepo.save(eConfigurationCodes);
            return "deleted";
        }
        throw new RuntimeException("ConfigCodes not found with codeId : " + codeId);
    }

}
