package com.factory.appraisal.vehiclesearchapp.controller;

import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.services.EDealerRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Author("Yogesh Kumar V")
@RestController
@RequestMapping("/dealerregistration")
public class DealerRegistrationController {
    @Autowired
    private EDealerRegistrationService eDealerRegistrationService;
    @PostMapping("/post")
    public ResponseEntity<DealerRegistration>postDealerRegistration
            (@RequestPart("data") DealerRegistration dealerRegistration, @RequestPart("profilePicture")MultipartFile profilePicture) throws IOException {
        return new ResponseEntity<>(eDealerRegistrationService.addDealerRegistration(dealerRegistration,profilePicture),
                HttpStatus.OK
        );
    }
    @GetMapping("/showall")
    public ResponseEntity<List<DealerRegistration>>showAllDealerRegistration(Integer pageNumber,Integer pageSize){
        return new ResponseEntity<>(eDealerRegistrationService.getDealerRegistrations(pageNumber,pageSize),
                HttpStatus.OK
        );
    }
    @PutMapping("/upgrade")
    public ResponseEntity<DealerRegistration>changeDealerRegistration
            (@PathVariable long dealerId,@RequestPart("data") DealerRegistration dealerRegistration,@RequestPart("profilePicture") MultipartFile profilePicture) throws IOException {
        return new ResponseEntity<>(eDealerRegistrationService.updateDealerRegistration(dealerId,dealerRegistration,profilePicture),
                HttpStatus.ACCEPTED
        );
    }
    public ResponseEntity<String> deleteDealerRegistration(long dealerId){
        return new ResponseEntity<>(eDealerRegistrationService.deleteDealerRegistration(dealerId),
                HttpStatus.OK
        );
    }


}
