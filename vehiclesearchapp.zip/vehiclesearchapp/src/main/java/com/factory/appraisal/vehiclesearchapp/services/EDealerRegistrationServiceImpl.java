package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.DealerRegistrationMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EDealerRegistration;
import com.factory.appraisal.vehiclesearchapp.repository.EDealerRegistrationRepo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Author("Yogesh Kumar V")
@Service
public class EDealerRegistrationServiceImpl implements EDealerRegistrationService{
    @Autowired
    private EDealerRegistrationRepo eDealerRegistrationRepo;
    @Autowired
    private DealerRegistrationMapper dealerRegistrationMapper;

    @Override
    public List<DealerRegistration> getDealerRegistrations(Integer pageNumber, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
        Page<EDealerRegistration> pageResult = eDealerRegistrationRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);
        List<EDealerRegistration>eDealerRegistrations=pageResult.toList();
        List<DealerRegistration> dealerRegistrations = dealerRegistrationMapper.modelsToDtos(eDealerRegistrations);
        return dealerRegistrations;
    }
    private final String FOLDER_PATH="D://picture_db/";
    @Override
    public DealerRegistration addDealerRegistration(DealerRegistration dealerRegistration, MultipartFile profilePicture) throws IOException {
        EDealerRegistration eDealerRegistration = dealerRegistrationMapper.dtoToModel(dealerRegistration);
        String extension = FilenameUtils.getExtension(profilePicture.getOriginalFilename());
        String filename = UUID.randomUUID().toString() +"."+ extension;
        Path filePath = Paths.get(FOLDER_PATH + filename);
        Files.write(filePath, profilePicture.getBytes()); //sending to folder
        eDealerRegistration.setProfilePicture(filename);
        return dealerRegistrationMapper.modeltoDto(eDealerRegistrationRepo.save(eDealerRegistration));
    }

    @Override
    public DealerRegistration updateDealerRegistration(long dealerId,DealerRegistration dealerRegistration, MultipartFile profilePicture) throws IOException {
        EDealerRegistration eDealerRegistration = eDealerRegistrationRepo.findById(dealerId).get();
        if (eDealerRegistration!=null){
            if (dealerRegistration.getValid()!=false){
                if(dealerRegistration.getName()!=null){
                    eDealerRegistration.setName(dealerRegistration.getName());
                }
                if ((dealerRegistration.getFirstName() != null)) {
                    eDealerRegistration.setFirstName(dealerRegistration.getFirstName());
                }
                if(dealerRegistration.getLastName()!=null){
                    eDealerRegistration.setLastName(dealerRegistration.getLastName());
                }
                if (dealerRegistration.getApartmentNumber()!=null){
                    eDealerRegistration.setApartmentNumber(dealerRegistration.getApartmentNumber());
                }
                if (dealerRegistration.getCity()!=null){
                    eDealerRegistration.setCity(dealerRegistration.getCity());
                }
                if (dealerRegistration.getEmail()!=null){
                    eDealerRegistration.setEmail(dealerRegistration.getEmail());
                }
                if (dealerRegistration.getPassword()!=null){
                    eDealerRegistration.setPassword(dealerRegistration.getPassword());
                }
                if (dealerRegistration.getPhoneNumber()!=null){
                    eDealerRegistration.setPhoneNumber(dealerRegistration.getPhoneNumber());
                }
                if (dealerRegistration.getProfilePicture()!=null){
                    eDealerRegistration.setProfilePicture(dealerRegistration.getProfilePicture());
                }
                if (dealerRegistration.getState()!=null){
                    eDealerRegistration.setState(dealerRegistration.getState());
                }
                if (dealerRegistration.getStreetAddress()!=null){
                    eDealerRegistration.setStreetAddress(dealerRegistration.getStreetAddress());
                }
                if (dealerRegistration.getZipCode()!=null){
                    eDealerRegistration.setZipCode(dealerRegistration.getZipCode());
                }
                if (dealerRegistration.getLatitude()!=null){
                    eDealerRegistration.setLatitude(dealerRegistration.getLatitude());
                }
                if (dealerRegistration.getLongitude()!=null){
                    eDealerRegistration.setLongitude(dealerRegistration.getLongitude());
                }
                if (dealerRegistration.getTaxCertificate()!=null){
                    eDealerRegistration.setTaxCertificate(dealerRegistration.getTaxCertificate());
                }
                if(dealerRegistration.getDealershipName()!=null){
                    eDealerRegistration.setDealershipName(dealerRegistration.getDealershipName());
                }
                if (dealerRegistration.getDealershipAddress()!=null){
                    eDealerRegistration.setDealershipAddress(dealerRegistration.getDealershipAddress());
                }
                if (dealerRegistration.getDealershipStreet()!=null){
                    eDealerRegistration.setDealershipStreet(dealerRegistration.getDealershipStreet());
                }
                if (dealerRegistration.getDealershipCity()!=null){
                    eDealerRegistration.setDealershipCity(dealerRegistration.getDealershipCity());
                }
                if (dealerRegistration.getDealershipZipCode()!=null){
                    eDealerRegistration.setDealershipZipCode(dealerRegistration.getDealershipZipCode());
                }
                if (dealerRegistration.getDealershipPhoneNumber()!=null){
                    eDealerRegistration.setDealershipPhoneNumber(dealerRegistration.getDealershipPhoneNumber());
                }
                if (dealerRegistration.getDealershipPicture()!=null){
                    eDealerRegistration.setDealershipPicture(dealerRegistration.getDealershipPicture());
                }
                if (dealerRegistration.getDealershipLicense()!=null){
                    eDealerRegistration.setDealershipPicture(dealerRegistration.getDealershipPicture());
                }
                if (dealerRegistration.getCorporationName()!=null) {
                    eDealerRegistration.setCorporationName(dealerRegistration.getCorporationName());
                }
                eDealerRegistration.setCreatedBy(dealerRegistration.getCreatedBy());
                eDealerRegistration.setCreatedOn(dealerRegistration.getCreatedOn());
                eDealerRegistration.setModifiedBy(dealerRegistration.getModifiedBy());
                eDealerRegistration.setModifiedOn(dealerRegistration.getModifiedOn());
                //add new file
                String extension = FilenameUtils.getExtension(profilePicture.getOriginalFilename());
                String fileName = UUID.randomUUID().toString() +"."+ extension;
                Path filePath = Paths.get(FOLDER_PATH + fileName);


                Files.write(filePath, profilePicture.getBytes()); //sending to folder

                //delete old file
                String old = FOLDER_PATH + eDealerRegistration.getProfilePicture();
                Path filePathOld = Paths.get(old);
                Files.delete(filePathOld);
                eDealerRegistration.setProfilePicture(fileName);



            }
            return dealerRegistrationMapper.modeltoDto(eDealerRegistrationRepo.save(eDealerRegistration));
        }
        else throw new RuntimeException("Did not find AppraisalVehicle of "+dealerId );
    }

    @Override
    public String deleteDealerRegistration(long dealerId) {
        EDealerRegistration eDealerRegistration = eDealerRegistrationRepo.findById(dealerId).get();
        if (eDealerRegistration!=null){
            eDealerRegistration.setValid(false);
            eDealerRegistrationRepo.save(eDealerRegistration);
            return "Deleted";
        }
        throw new RuntimeException("DealerRegistration not found with dealerId : "+dealerId);
    }
}
