package com.factory.appraisal.vehiclesearchapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclesearchappApplicationTests {

	@Test
	void contextLoads() {
	}

}
